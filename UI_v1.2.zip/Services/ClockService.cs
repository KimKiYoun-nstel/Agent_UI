using System;

namespace Agent.UI.Wpf.Services
{
    public sealed class ClockService
    {
        public DateTime Now() => DateTime.Now;
    }
}
