# Wire Protocol Reference (UI ↔ Gateway)

본 문서는 업로드된 레거시 프로젝트(`ConnextControlUI` + `DkmRtpIpc` + `RtpDdsGateway`)를 분석하여,
새 WPF UI가 **동일한 프레이밍/코덱/소켓 규약**으로 통신하기 위해 정리한 레퍼런스입니다.
(분석 근거: `DkmRtpIpc/include/dkmrtp_ipc_messages.hpp`, `DkmRtpIpc/src/dkmrtp_ipc.cpp`,
`ConnextControlUI/include/rpc_envelope.hpp`, `RtpDdsGateway/src/ipc_adapter.cpp` 등)

---

## 1) 데이터 경로 개요

UI(Client) ──UDP/RIPC──▶ Gateway(Server)  
- **UI**: Qt UI가 `DkmRtpIpc` 클라이언트를 사용해 **프레임 헤더 + CBOR(Map)** 를 보냄.  
- **Gateway**: 헤더를 검사하고 **CBOR Map**을 파싱하여 로직 처리 후, **RSP(응답) 또는 EVT(이벤트)** 를 동일 규격으로 송신.

---

## 2) RIPC 프레임 헤더 (고정 24바이트, 네트워크 바이트오더)

| 필드     | 타입   | 설명/값 |
|---------|--------|--------|
| `magic` | u32    | `0x52495043` (ASCII 'RIPC') |
| `version` | u16  | `0x0001` |
| `type`  | u16    | `0x1000`=REQ, `0x1001`=RSP, `0x1002`=EVT |
| `corr_id` | u32  | 요청–응답 상관관계 ID(클라에서 증가) |
| `length` | u32   | **뒤따르는 CBOR 페이로드 길이**(bytes) |
| `ts_ns` | u64    | 송신 시각(ns). 진단용 |

**근거**: `DkmRtpIpc/include/dkmrtp_ipc_messages.hpp`(헤더와 타입 상수),  
`DkmRtpIpc/src/dkmrtp_ipc.cpp`(전송 시 `htonl/htons/htonll`로 write).

> 모든 필드는 **big-endian(network order)** 로 기록/해석합니다.

---

## 3) 메시지 타입

- `0x1000` **REQ**: UI → Gateway 요청
- `0x1001` **RSP**: Gateway → UI 응답(동일 `corr_id`)
- `0x1002` **EVT**: Gateway → UI 이벤트(비동기 알림)

---

## 4) CBOR 페이로드 (Map 구조)

레거시 Qt 코드는 `nlohmann::json::to_cbor(...)` 를 사용하여 **CBOR Map**을 직렬화합니다.  
**중요**: *CBOR ByteString(JSON)* 이 아니라 **CBOR Map** 그 자체입니다.

### REQ(JSON 의미)
```json
{
  "op": "hello" | "create" | "write" | "...",
  "target": "agent" | "participant" | "publisher" | "subscriber" | "writer" | "reader",
  "args": { /* domain/name/topic/type/qos 등 */ },
  "data": { /* publish payload */ },
  "proto": 1
}
```

### RSP(JSON 의미; 대표)
```json
{ "ok": true,  "result": { "action": "...", "...": "..." } }
{ "ok": false, "err": <int or string>, "category": <int>, "msg": "reason" }
```

### EVT(JSON 의미; 대표)
```json
{ "evt": "data", "topic": "<topic>", "type": "<type>", "display": { /* 샘플 */ } }
```

**근거**: `ConnextControlUI/include/rpc_envelope.hpp`(to_cbor), `RtpDdsGateway/src/ipc_adapter.cpp`(on_request 처리, CMD→EVT 변환).

---

## 5) Qt IPC 전송 흐름(요약)

1. **CBOR Map** 페이로드 생성 (`rpc_envelope.to_cbor()`).
2. 헤더 채움:
   - `magic=0x52495043`, `ver=0x0001`, `type=REQ(0x1000)`,
   - `corr_id = ++counter`, `length = payload.size`, `ts_ns = now_ns()`
   - 전부 **network order** 변환(htonl/htons/htonll).
3. **헤더(24B) + 페이로드**를 **연속 바이트**로 전송.
4. 서버 수신 후 헤더/길이 검증 → CBOR Map 파싱 → 처리 → **RSP/EVT** 프레임 송신.
5. 클라이언트는 `corr_id`로 RSP 매칭, EVT는 별도 콜백으로 전달.

**근거**: `DkmRtpIpc/src/dkmrtp_ipc.cpp` (send_raw, 수신 루프).

---

## 6) 소켓/네트워크 조건

- **IPv4(AF_INET)** 소켓 사용. 클라이언트는 **Connect(remote)** 으로 목적지 고정 + **Bind(local)**(임의포트 OK).  
- 서버는 `bind(serverPort)` 후 `recvfrom`으로 수신, peer 기억 후 `sendto(peer)` 송신.  
- 브로드캐스트/멀티캐스트 사용 흔적 없음(유니캐스트).

**근거**: `DkmRtpIpc/src/dkmrtp_ipc.cpp` (winsock, connect/bind/send/recv 경로).

---

## 7) hello 왕복(의미)

- **REQ**: `{ "op":"hello", "target":"agent", "proto":1 }` → CBOR Map → 프레임 송신
- **RSP 예시 의미**: `{ "ok":true, "result":{"action":"hello","proto":1,"cap":[...]}}`
- 목적: 경로/프로토콜 일치, 방화벽/라우팅 확인, 서버 준비 상태 확인.

---

## 8) WPF 구현 시 필수 정합 포인트

- **프레이밍**: 반드시 **RIPC 헤더 + CBOR Map** 으로 송신/수신.
- **엔디안**: 모든 헤더 필드 **network order**.
- **코덱**: Map 기반 인코딩/디코딩(키 소문자 일치). ByteString(JSON) 금지.
- **IPv4 소켓** 사용(서버가 IPv4 수신).
- **corr_id** 증가/매칭 유지.

---

## 9) 진단 팁

- 송신 직전 **헤더 + 앞 32바이트 payload** HEX를 로그로 남겨 Qt와 비교.
- 수신 시 헤더 검증 실패(매직/버전/type/length)는 즉시 drop + 이유 로그.
- 타임아웃은 요청별 CTS로 관리(5초 권장; 환경에 맞춰 조정).

---

## 10) 참고 코드 스니펫 (발췌)

### (A) 헤더 작성(C++ 레거시)
```cpp
Header h;
h.magic   = htonl(0x52495043);
h.version = htons(0x0001);
h.type    = htons(MSG_FRAME_REQ);
h.corr_id = htonl(corr_id);
h.length  = htonl(payload_len);
h.ts_ns   = htonll(now_ns());
// [헤더 24B] + [CBOR Map payload] 연속 전송
```

### (B) Qt RPC Envelope → CBOR Map
```cpp
std::vector<uint8_t> RpcEnvelope::to_cbor() const {
    return nlohmann::json::to_cbor(j_); // j_는 {"op","target","args","data","proto"} 구조
}
```

### (C) 서버 on_request(요지)
```cpp
cb.on_request = [&](const Header& h, const uint8_t* body, uint32_t len) {
    // body: CBOR Map
    // op/target에 따라 처리 → RSP({ok:true/false, result/err}) 또는 EVT 발행
};
```

---

본 문서는 새 UI(WPF)가 레거시와 **동일 규약**으로 통신하기 위한 기준선입니다.  
이후 단계(3.5/4/5…)의 구현 가이드에서 이 문서를 참조하여 헤더/코덱/소켓 옵션을 정확히 맞추세요.
